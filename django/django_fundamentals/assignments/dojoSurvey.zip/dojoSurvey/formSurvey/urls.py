from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="home"),
    path('result', views.create_user, name="create_user"), # was users
    #path('result', views.result, name="result"),
    #path('success', views.success_message, name="success")
]
